# Terraform Configurations and Definitions
This repository contains top-level implementations of reusable terraform modules, organized by environment/cluster.

## Terraform Version
Each project subdirectory contains a symlink to a file at the root of this repo called `.tf_version`.

```
terraform {
  required_version = "~> 0.10.0"
}
```

This ensures that major and minor upgrades are not performed without peer review, while still making it easy to upgrade version
constraints everywhere.

## Terraform Remote State
Each project should utilize backend.tf to manage remote state/locking behavior (see example below).

```
terraform {
  backend "s3" {
    encrypt = true
    bucket = "568991612377-predix-ger-dmz-ec1-tf-state"
    key    = "iam/terraform.tfstate"
    region = "eu-central-1"
    dynamodb_table = "568991612377-predix-ger-dmz-ec1-iam"
  }
}

```
## Local Variables
Any `.tfvars` file other than the default `terraform.tfvars` file will be excluded from git.

Any user specific information (keys, usernames, etc.), should be saved in a separate .tfvars file and included
using the `-var-file` option, or via environment variables:

```
# Either of these would be acceptable

# Via a local tfvars file
terragrunt plan -var-file="mysecrets.tfvars"

# Via environment variables
TF_VAR_secret_password=12345 terragrunt plan
```
